# generator.sage

import random

p = 257
F = GF(p)

v = 16
o = 15
n = v + o
m = 31

FLAG = b"TDCTF{XXXXXXXXXXXXXXXXXXXXXXXXXXX}"
assert len(FLAG) == n

X_flag = vector(F, [int(b) for b in FLAG])

while True:
    T = random_matrix(F, n, n)
    if T.is_invertible():
        break

Q_prime_list = []
for k in range(m):
    V_k = random_matrix(F, v, v)
    V_k = V_k + V_k.transpose()
    
    M_k = random_matrix(F, v, o)
    Zero_k = matrix(F, o, o)
    
    Q_k_prime = block_matrix(F, [
        [V_k, M_k],
        [M_k.transpose(), Zero_k]
    ])
    Q_prime_list.append(Q_k_prime)

Q_public_list = []
for k in range(m):
    Q_k = T.transpose() * Q_prime_list[k] * T
    Q_public_list.append(Q_k)

ciphertext = [int(X_flag * Q_k * X_flag) for Q_k in Q_public_list]

with open("public_key.txt", "w") as f:
    f.write(f"p = {p}\n")
    f.write(f"v = {v}\n")
    f.write(f"o = {o}\n")
    f.write(f"n = {n}\n")
    f.write(f"m = {m}\n")
    f.write("Q_matrices = [\n")
    for Q in Q_public_list:
        f.write(f"    {Q.list()},\n")
    f.write("]\n")

with open("ciphertext.txt", "w") as f:
    f.write(f"ciphertext = {ciphertext}\n")

print("[+] Done! Challenge files created.")
